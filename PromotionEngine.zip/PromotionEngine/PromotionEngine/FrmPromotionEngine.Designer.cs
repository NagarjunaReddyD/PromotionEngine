﻿namespace PromotionEngine
{
    partial class FrmPromotionEngine
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblSummaryValue = new System.Windows.Forms.Label();
            this.lblSummary = new System.Windows.Forms.Label();
            this.lblPromoCDValue = new System.Windows.Forms.Label();
            this.lblPromoCD = new System.Windows.Forms.Label();
            this.lblPromoDValue = new System.Windows.Forms.Label();
            this.lblPromoD = new System.Windows.Forms.Label();
            this.lblPromoCValue = new System.Windows.Forms.Label();
            this.lblPromoC = new System.Windows.Forms.Label();
            this.lblPromoBValue = new System.Windows.Forms.Label();
            this.lblPromoB = new System.Windows.Forms.Label();
            this.lblPromoAValue = new System.Windows.Forms.Label();
            this.lblPromoA = new System.Windows.Forms.Label();
            this.btnClear = new System.Windows.Forms.Button();
            this.lblValidate = new System.Windows.Forms.Label();
            this.lblPriceD = new System.Windows.Forms.Label();
            this.lblPriceC = new System.Windows.Forms.Label();
            this.lblPriceB = new System.Windows.Forms.Label();
            this.lblPriceA = new System.Windows.Forms.Label();
            this.btnCheckOut = new System.Windows.Forms.Button();
            this.cmbD = new System.Windows.Forms.ComboBox();
            this.cmbC = new System.Windows.Forms.ComboBox();
            this.cmbB = new System.Windows.Forms.ComboBox();
            this.cmbA = new System.Windows.Forms.ComboBox();
            this.chkD = new System.Windows.Forms.CheckBox();
            this.chkC = new System.Windows.Forms.CheckBox();
            this.chkB = new System.Windows.Forms.CheckBox();
            this.chkA = new System.Windows.Forms.CheckBox();
            this.SuspendLayout();
            // 
            // lblSummaryValue
            // 
            this.lblSummaryValue.AutoSize = true;
            this.lblSummaryValue.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSummaryValue.Location = new System.Drawing.Point(456, 208);
            this.lblSummaryValue.Name = "lblSummaryValue";
            this.lblSummaryValue.Size = new System.Drawing.Size(126, 13);
            this.lblSummaryValue.TabIndex = 57;
            this.lblSummaryValue.Text = "Summary of Products";
            // 
            // lblSummary
            // 
            this.lblSummary.AutoSize = true;
            this.lblSummary.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSummary.Location = new System.Drawing.Point(378, 208);
            this.lblSummary.Name = "lblSummary";
            this.lblSummary.Size = new System.Drawing.Size(61, 13);
            this.lblSummary.TabIndex = 56;
            this.lblSummary.Text = "Summary:";
            // 
            // lblPromoCDValue
            // 
            this.lblPromoCDValue.AutoSize = true;
            this.lblPromoCDValue.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPromoCDValue.Location = new System.Drawing.Point(456, 149);
            this.lblPromoCDValue.Name = "lblPromoCDValue";
            this.lblPromoCDValue.Size = new System.Drawing.Size(94, 13);
            this.lblPromoCDValue.TabIndex = 55;
            this.lblPromoCDValue.Text = "After Promotion";
            // 
            // lblPromoCD
            // 
            this.lblPromoCD.AutoSize = true;
            this.lblPromoCD.Location = new System.Drawing.Point(342, 149);
            this.lblPromoCD.Name = "lblPromoCD";
            this.lblPromoCD.Size = new System.Drawing.Size(97, 13);
            this.lblPromoCD.TabIndex = 54;
            this.lblPromoCD.Text = "After Promotion C&D";
            // 
            // lblPromoDValue
            // 
            this.lblPromoDValue.AutoSize = true;
            this.lblPromoDValue.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPromoDValue.Location = new System.Drawing.Point(456, 176);
            this.lblPromoDValue.Name = "lblPromoDValue";
            this.lblPromoDValue.Size = new System.Drawing.Size(104, 13);
            this.lblPromoDValue.TabIndex = 53;
            this.lblPromoDValue.Text = "Before Promotion";
            // 
            // lblPromoD
            // 
            this.lblPromoD.AutoSize = true;
            this.lblPromoD.Location = new System.Drawing.Point(342, 176);
            this.lblPromoD.Name = "lblPromoD";
            this.lblPromoD.Size = new System.Drawing.Size(99, 13);
            this.lblPromoD.TabIndex = 52;
            this.lblPromoD.Text = "Before Promotion D";
            // 
            // lblPromoCValue
            // 
            this.lblPromoCValue.AutoSize = true;
            this.lblPromoCValue.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPromoCValue.Location = new System.Drawing.Point(456, 121);
            this.lblPromoCValue.Name = "lblPromoCValue";
            this.lblPromoCValue.Size = new System.Drawing.Size(104, 13);
            this.lblPromoCValue.TabIndex = 51;
            this.lblPromoCValue.Text = "Before Promotion";
            // 
            // lblPromoC
            // 
            this.lblPromoC.AutoSize = true;
            this.lblPromoC.Location = new System.Drawing.Point(341, 121);
            this.lblPromoC.Name = "lblPromoC";
            this.lblPromoC.Size = new System.Drawing.Size(98, 13);
            this.lblPromoC.TabIndex = 50;
            this.lblPromoC.Text = "Before Promotion C";
            // 
            // lblPromoBValue
            // 
            this.lblPromoBValue.AutoSize = true;
            this.lblPromoBValue.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPromoBValue.Location = new System.Drawing.Point(456, 78);
            this.lblPromoBValue.Name = "lblPromoBValue";
            this.lblPromoBValue.Size = new System.Drawing.Size(94, 13);
            this.lblPromoBValue.TabIndex = 49;
            this.lblPromoBValue.Text = "After Promotion";
            // 
            // lblPromoB
            // 
            this.lblPromoB.AutoSize = true;
            this.lblPromoB.Location = new System.Drawing.Point(342, 74);
            this.lblPromoB.Name = "lblPromoB";
            this.lblPromoB.Size = new System.Drawing.Size(89, 13);
            this.lblPromoB.TabIndex = 48;
            this.lblPromoB.Text = "After Promotion B";
            // 
            // lblPromoAValue
            // 
            this.lblPromoAValue.AutoSize = true;
            this.lblPromoAValue.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPromoAValue.Location = new System.Drawing.Point(456, 37);
            this.lblPromoAValue.Name = "lblPromoAValue";
            this.lblPromoAValue.Size = new System.Drawing.Size(94, 13);
            this.lblPromoAValue.TabIndex = 47;
            this.lblPromoAValue.Text = "After Promotion";
            // 
            // lblPromoA
            // 
            this.lblPromoA.AutoSize = true;
            this.lblPromoA.Location = new System.Drawing.Point(342, 37);
            this.lblPromoA.Name = "lblPromoA";
            this.lblPromoA.Size = new System.Drawing.Size(89, 13);
            this.lblPromoA.TabIndex = 46;
            this.lblPromoA.Text = "After Promotion A";
            // 
            // btnClear
            // 
            this.btnClear.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnClear.Location = new System.Drawing.Point(194, 203);
            this.btnClear.Name = "btnClear";
            this.btnClear.Size = new System.Drawing.Size(121, 23);
            this.btnClear.TabIndex = 45;
            this.btnClear.Text = "Clear";
            this.btnClear.UseVisualStyleBackColor = true;
            this.btnClear.Click += new System.EventHandler(this.btnClear_Click);
            // 
            // lblValidate
            // 
            this.lblValidate.AutoSize = true;
            this.lblValidate.ForeColor = System.Drawing.Color.Red;
            this.lblValidate.Location = new System.Drawing.Point(56, 243);
            this.lblValidate.Name = "lblValidate";
            this.lblValidate.Size = new System.Drawing.Size(96, 13);
            this.lblValidate.TabIndex = 44;
            this.lblValidate.Text = "Validate CheckOut";
            // 
            // lblPriceD
            // 
            this.lblPriceD.AutoSize = true;
            this.lblPriceD.Location = new System.Drawing.Point(121, 170);
            this.lblPriceD.Name = "lblPriceD";
            this.lblPriceD.Size = new System.Drawing.Size(34, 13);
            this.lblPriceD.TabIndex = 43;
            this.lblPriceD.Text = "Price:";
            // 
            // lblPriceC
            // 
            this.lblPriceC.AutoSize = true;
            this.lblPriceC.Location = new System.Drawing.Point(121, 116);
            this.lblPriceC.Name = "lblPriceC";
            this.lblPriceC.Size = new System.Drawing.Size(34, 13);
            this.lblPriceC.TabIndex = 42;
            this.lblPriceC.Text = "Price:";
            // 
            // lblPriceB
            // 
            this.lblPriceB.AutoSize = true;
            this.lblPriceB.Location = new System.Drawing.Point(121, 72);
            this.lblPriceB.Name = "lblPriceB";
            this.lblPriceB.Size = new System.Drawing.Size(34, 13);
            this.lblPriceB.TabIndex = 41;
            this.lblPriceB.Text = "Price:";
            // 
            // lblPriceA
            // 
            this.lblPriceA.AutoSize = true;
            this.lblPriceA.Location = new System.Drawing.Point(121, 34);
            this.lblPriceA.Name = "lblPriceA";
            this.lblPriceA.Size = new System.Drawing.Size(34, 13);
            this.lblPriceA.TabIndex = 40;
            this.lblPriceA.Text = "Price:";
            // 
            // btnCheckOut
            // 
            this.btnCheckOut.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCheckOut.Location = new System.Drawing.Point(34, 203);
            this.btnCheckOut.Name = "btnCheckOut";
            this.btnCheckOut.Size = new System.Drawing.Size(121, 23);
            this.btnCheckOut.TabIndex = 39;
            this.btnCheckOut.Text = "CheckOut";
            this.btnCheckOut.UseVisualStyleBackColor = true;
            this.btnCheckOut.Click += new System.EventHandler(this.btnCheckOut_Click);
            // 
            // cmbD
            // 
            this.cmbD.FormattingEnabled = true;
            this.cmbD.Items.AddRange(new object[] {
            "1",
            "2",
            "3",
            "4",
            "5",
            "6"});
            this.cmbD.Location = new System.Drawing.Point(194, 168);
            this.cmbD.Name = "cmbD";
            this.cmbD.Size = new System.Drawing.Size(121, 21);
            this.cmbD.TabIndex = 38;
            this.cmbD.Text = "Qty";
            // 
            // cmbC
            // 
            this.cmbC.FormattingEnabled = true;
            this.cmbC.Items.AddRange(new object[] {
            "1",
            "2",
            "3",
            "4",
            "5",
            "6"});
            this.cmbC.Location = new System.Drawing.Point(194, 113);
            this.cmbC.Name = "cmbC";
            this.cmbC.Size = new System.Drawing.Size(121, 21);
            this.cmbC.TabIndex = 37;
            this.cmbC.Text = "Qty";
            // 
            // cmbB
            // 
            this.cmbB.FormattingEnabled = true;
            this.cmbB.Items.AddRange(new object[] {
            "1",
            "2",
            "3",
            "4",
            "5",
            "6"});
            this.cmbB.Location = new System.Drawing.Point(194, 70);
            this.cmbB.Name = "cmbB";
            this.cmbB.Size = new System.Drawing.Size(121, 21);
            this.cmbB.TabIndex = 36;
            this.cmbB.Text = "Qty";
            // 
            // cmbA
            // 
            this.cmbA.FormattingEnabled = true;
            this.cmbA.Items.AddRange(new object[] {
            "1",
            "2",
            "3",
            "4",
            "5",
            "6",
            "7",
            "8"});
            this.cmbA.Location = new System.Drawing.Point(194, 34);
            this.cmbA.Name = "cmbA";
            this.cmbA.Size = new System.Drawing.Size(121, 21);
            this.cmbA.TabIndex = 35;
            this.cmbA.Text = "Qty";
            // 
            // chkD
            // 
            this.chkD.AutoSize = true;
            this.chkD.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkD.Location = new System.Drawing.Point(33, 168);
            this.chkD.Name = "chkD";
            this.chkD.Size = new System.Drawing.Size(83, 17);
            this.chkD.TabIndex = 34;
            this.chkD.Text = "Product D";
            this.chkD.UseVisualStyleBackColor = true;
            // 
            // chkC
            // 
            this.chkC.AutoSize = true;
            this.chkC.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkC.Location = new System.Drawing.Point(33, 117);
            this.chkC.Name = "chkC";
            this.chkC.Size = new System.Drawing.Size(82, 17);
            this.chkC.TabIndex = 33;
            this.chkC.Text = "Product C";
            this.chkC.UseVisualStyleBackColor = true;
            // 
            // chkB
            // 
            this.chkB.AutoSize = true;
            this.chkB.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkB.Location = new System.Drawing.Point(33, 70);
            this.chkB.Name = "chkB";
            this.chkB.Size = new System.Drawing.Size(82, 17);
            this.chkB.TabIndex = 32;
            this.chkB.Text = "Product B";
            this.chkB.UseVisualStyleBackColor = true;
            // 
            // chkA
            // 
            this.chkA.AutoSize = true;
            this.chkA.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkA.Location = new System.Drawing.Point(33, 30);
            this.chkA.Name = "chkA";
            this.chkA.Size = new System.Drawing.Size(82, 17);
            this.chkA.TabIndex = 31;
            this.chkA.Text = "Product A";
            this.chkA.UseVisualStyleBackColor = true;
            // 
            // FrmPromotionEngine
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.lblSummaryValue);
            this.Controls.Add(this.lblSummary);
            this.Controls.Add(this.lblPromoCDValue);
            this.Controls.Add(this.lblPromoCD);
            this.Controls.Add(this.lblPromoDValue);
            this.Controls.Add(this.lblPromoD);
            this.Controls.Add(this.lblPromoCValue);
            this.Controls.Add(this.lblPromoC);
            this.Controls.Add(this.lblPromoBValue);
            this.Controls.Add(this.lblPromoB);
            this.Controls.Add(this.lblPromoAValue);
            this.Controls.Add(this.lblPromoA);
            this.Controls.Add(this.btnClear);
            this.Controls.Add(this.lblValidate);
            this.Controls.Add(this.lblPriceD);
            this.Controls.Add(this.lblPriceC);
            this.Controls.Add(this.lblPriceB);
            this.Controls.Add(this.lblPriceA);
            this.Controls.Add(this.btnCheckOut);
            this.Controls.Add(this.cmbD);
            this.Controls.Add(this.cmbC);
            this.Controls.Add(this.cmbB);
            this.Controls.Add(this.cmbA);
            this.Controls.Add(this.chkD);
            this.Controls.Add(this.chkC);
            this.Controls.Add(this.chkB);
            this.Controls.Add(this.chkA);
            this.Name = "FrmPromotionEngine";
            this.Text = "Shopping Cart";
            this.Load += new System.EventHandler(this.FrmPromotionEngine_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblSummaryValue;
        private System.Windows.Forms.Label lblSummary;
        private System.Windows.Forms.Label lblPromoCDValue;
        private System.Windows.Forms.Label lblPromoCD;
        private System.Windows.Forms.Label lblPromoDValue;
        private System.Windows.Forms.Label lblPromoD;
        private System.Windows.Forms.Label lblPromoCValue;
        private System.Windows.Forms.Label lblPromoC;
        private System.Windows.Forms.Label lblPromoBValue;
        private System.Windows.Forms.Label lblPromoB;
        private System.Windows.Forms.Label lblPromoAValue;
        private System.Windows.Forms.Label lblPromoA;
        private System.Windows.Forms.Button btnClear;
        private System.Windows.Forms.Label lblValidate;
        private System.Windows.Forms.Label lblPriceD;
        private System.Windows.Forms.Label lblPriceC;
        private System.Windows.Forms.Label lblPriceB;
        private System.Windows.Forms.Label lblPriceA;
        private System.Windows.Forms.Button btnCheckOut;
        private System.Windows.Forms.ComboBox cmbD;
        private System.Windows.Forms.ComboBox cmbC;
        private System.Windows.Forms.ComboBox cmbB;
        private System.Windows.Forms.ComboBox cmbA;
        private System.Windows.Forms.CheckBox chkD;
        private System.Windows.Forms.CheckBox chkC;
        private System.Windows.Forms.CheckBox chkB;
        private System.Windows.Forms.CheckBox chkA;
    }
}

